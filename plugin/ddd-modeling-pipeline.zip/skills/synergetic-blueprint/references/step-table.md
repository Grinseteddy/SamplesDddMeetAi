# Step-by-step notes

Each block: what to ask, what a good upload looks like, how to generate, what to
hand to the knowledge graph, and what to carry forward.

## Step 1 — Brainstorming result (optional)

- **Ask:** skip / upload (photo of whiteboard, sticky board, Miro export, idea
  list) / generate (run a short brainstorm with the user on a stated topic).
- **Upload:** load `devils-advocate`. Critique for groupthink, premature
  convergence, hidden assumptions. Then ask whether the user wants to accept
  the original, or a *new* brainstorm result that incorporates the critique.
- **Generate:** load `brainstorm-participant`. Ask for the topic and a time box
  in ideas (e.g. 20). Produce the list, then run `devils-advocate` on it.
- **Ingest as:** `dkg:Brainstorm`. The graph seeds here if it is the first
  artifact — ask for the project short name.
- **Carry forward:** the idea list (feeds step 2 drafts and step 4 components).

## Step 2 — Capability Map (optional)

- **Upload:** photo / sticky board / list of capabilities with levels.
  Load `capability-map-critic`; mark core / supporting / generic.
- **Generate:** draft a two-level map from the brainstorm and any stated
  strategy anchor (North Star Metric, canvas, impact map — ask for one, accept
  "none"). Show it, let the user edit, then critique the edited version.
- **Ingest as:** `dkg:CapabilityMap` with the core/supporting/generic markings
  as the critique's recommendation, not as fact.
- **Carry forward:** the map + critique. Step 3 cannot generate without both.

## Step 3 — Core Domain Chart (optional)

- **Upload:** load `core-domain-chart-critic`. Reconstruct placements and
  patterns; check against the step 2 map if present.
- **Generate:** requires step 2 map and critique. Load `core-domain-chart-author`;
  render the SVG with grey current positions and black target positions.
  If step 2 was skipped, offer to do step 2 now or skip step 3.
- **Ingest as:** `dkg:CoreDomainChart`. Each move (grey → black) becomes a
  recommendation node linked to the capability it moves.

## Step 4 — Wardley Map (optional)

- **Upload:** load `wardley-map-critic`. Anchor, value chain, evolution stages,
  doctrine, inertia.
- **Generate:** draft components from steps 1–3 with a proposed evolution stage
  each; ask the user to fix stages; then critique. Say plainly that a generated
  Wardley map is a strawman for the room, not situational awareness.
- **Ingest as:** `dkg:WardleyMap`. Link components to capabilities by name
  through the merge ledger — never merge silently.

## Step 5 — Domain Story (optional)

- **Upload:** picture, egon.io export, or numbered sentences. Load
  `domain-story-critic`. Check verbs, actors, work objects, sequence, scope.
- **Generate:** load `domain-story-seeder`. If a step 2 or 4 map exists, list
  its components and let the user pick up to three to centre the story on.
- **Ingest as:** `dkg:DomainStory`, one per story. Several stories are fine.
- **Carry forward:** the sentences — steps 6, 8, 9, 10 read them.

## Step 6 — Visual Glossary (mandatory)

- **Upload:** picture or transcription. Load `visual-glossary-interpreter`;
  produce the Glossary Brief (term catalogue, cardinalities, derived model,
  open questions).
- **Generate:** extract the nouns from the step 5 story (or ask the user for a
  domain description if no story), propose relationships and cardinalities as
  questions, and render the picture with the renderer bundled in
  `visual-glossary-updater/scripts`. Let the user edit; re-interpret the edited
  version.
- **Ingest as:** `dkg:VisualGlossary` (v1). Every term keeps its spelling.
- **Carry forward:** the Glossary Brief; step 9 revises it.

## Step 7 — Bounded contexts in an EventStorming board (optional)

- **Upload:** board photo, Miro export, past-tense event list. Load
  `pivotal-event-boundary-finder`; propose pivotal events, veto with the
  narrow-interface test, name the segments as candidate contexts.
- **Generate:** first seed events with `domain-story-event-seeder` (if a story
  exists) or `event-storming-seeder` (from a description), let the user edit
  the timeline, then find the pivotal events on the edited list.
- **Not ingested here.** The board *with* its context lines is the artifact of
  step 8. Pass the divider lines forward.

## Step 8 — EventStorming with contexts, or contexts from Domain Stories (mandatory)

Ask which path: **board** or **stories**.

- **Board path:** load `event-storming-interpreter` on the board with the
  step 7 lines (or the user's own lines). Output bounded contexts, aggregates,
  commands, policies, hotspots.
- **Stories path:** load `domain-story-context-finder` on the step 5 stories
  (if step 5 was skipped, ask for a story now — this path needs one). Output
  named contexts with cited sentence evidence and alternative cuts.
- **Ingest as:** `dkg:EventStormingBoard` + `dkg:BoundedContext` nodes, or
  `dkg:BoundedContext` nodes attached to the stories. Contested sentences go in
  as open questions.
- **Carry forward:** the list of bounded contexts. Steps 9–11 need it.

## Step 9 — Updated Visual Glossary (mandatory)

- **Upload:** the redrawn glossary. Load `domain-story-glossary-consistency`
  against every story, then `visual-glossary-interpreter` for the new brief.
  Additionally check that every glossary term sits in exactly one of the
  step 8 contexts and that the glossary's colouring matches those contexts.
- **Generate:** load `visual-glossary-updater`; redraw the step 6 glossary with
  the step 8 contexts as colours. Show, let the user edit, then run the two
  consistency checks above on the edited version.
- **Ingest as:** `dkg:VisualGlossary` v2 with `dkg:revisionOf` v1 — use the
  graph's **revise** mode and report the diff (added / removed / changed).

## Step 10 — Event Model (optional)

- **Upload:** board photos (may need stitching) or event-model-author output.
  Load `event-model-author` in review mode: check swimlanes equal the step 8
  contexts, every slice has a wireframe and a Given/When/Then, information is
  complete.
- **Generate:** load `event-model-author` with the step 5 stories and the
  step 8 contexts. If step 7/8 produced events, offer them as found events.
- **Ingest as:** `dkg:EventModel` with slices linked to contexts.

## Step 11 — Context Map + full consistency check (mandatory)

- **Upload:** the team's context map. Load `context-map-board-consistency`
  (against the board from 7/8 if any) and report reversed arrows, empty edges,
  duplicated nodes, unsupported patterns.
- **Generate:** load `event-storming-context-mapper` on the step 8 result.
  Give every border a direction, pattern, contract and mechanism. If step 8
  took the stories path, derive ownership from the stories' work objects and
  say that the map is weaker evidence than a board would give.
- **Ingest as:** `dkg:ContextMap`.
- **Then the closing report** described in SKILL.md: artifacts table,
  contradictions, orphans, and every unanswered question grouped by step.

# Ledger format (`pipeline-log.md`)

```
| Step | Name | Decision | Artifact | Accepted | Ingested | Open questions |
|------|------|----------|----------|----------|----------|----------------|
| 1 | Brainstorm | upload | brainstorm.jpg | y | y | 2 |
| 2 | Capability Map | skip | — | — | — | — |
```

Update the row the moment the decision is made, again on acceptance, and
again after ingest.

# Dependencies (what to re-check when a step is revisited)

| Revised step | Downstream steps that depend on it |
|---|---|
| 1 Brainstorm | 2, 4 (only if generated from it) |
| 2 Capability Map | 3, 4, 5 (if the story was seeded from a map) |
| 3 Core Domain Chart | 11 (only the closing report) |
| 4 Wardley Map | 5 (if seeded from it), 11 |
| 5 Domain Story | 6, 8 (stories path), 9, 10, 11 |
| 6 Visual Glossary | 9, 10, 11 |
| 7 Boundary lines | 8 (board path) |
| 8 Bounded contexts | 9, 10, 11 |
| 9 Updated Glossary | 10, 11 |
| 10 Event Model | 11 |

# Downstream re-checks (run these, do not regenerate)

| Step to re-check | Check to run | Skill |
|---|---|---|
| 2 | Are the new ideas / dropped ideas reflected as capabilities? List ideas with no capability and capabilities whose source idea is gone. | `capability-map-critic` (fidelity section only) |
| 3 | Does every plotted capability still exist on the map, with the same level? | `core-domain-chart-critic` (vs capability map) |
| 4 | Do map components still match capabilities by name via the merge ledger? | `wardley-map-critic` (anchor + components only) |
| 5 | Does the story still use the map's focus components? | `domain-story-critic` (fidelity to map) |
| 6 | Every story noun has a glossary term, every glossary term still occurs in some story; cardinalities not contradicted | `domain-story-glossary-consistency` |
| 8 (stories path) | Does every sentence of the revised story still fall in exactly one context? New sentences with no context, contexts with no remaining sentences, contested sentences | `domain-story-context-finder` (validate-existing-cut mode) |
| 8 (board path) | Do the board's actors and work objects still match the story? | `event-storming-interpreter` vs story: term ledger only |
| 9 | Same as 6, plus every term in exactly one step-8 context | `domain-story-glossary-consistency` + context check |
| 10 | Every swimlane is a current context; every slice's command/event/read model still names existing glossary terms; slices whose triggering story step disappeared | `event-model-author` review mode |
| 11 | Every context on the map exists in step 8; every border contract names objects the glossary still has; owners unchanged | `context-map-board-consistency` |

Worked example — user reloads the Domain Stories after step 8 (stories path)
was done:

1. Revise step 5: critique the new stories, accept, ingest as v2 with the diff
   (say: "Actor *Dispatcher* added, sentence 7 removed, *Bike* renamed
   *Bicycle*").
2. Re-check 6: `Bike`→`Bicycle` contradicts the glossary; new noun *Route
   sheet* undefined. Offer keep / patch / redo.
3. Re-check 8: sentence 7 was the only sentence in context *Returns*; new
   sentences 9–11 fall in no context. Offer keep / patch / redo.
4. Re-check 9, 10, 11 in turn, each against the patched or kept result of the
   previous one.
5. Update ledger rows 5, 6, 8, 9, 10, 11 with `r2`; continue at the frontier
   or re-run the closing report.
