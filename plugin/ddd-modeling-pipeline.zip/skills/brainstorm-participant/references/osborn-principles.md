# Osborn's Principles & Techniques

Source basis: Osborn, *Applied Imagination: Principles and Procedures of
Creative Thinking*. This file expands the four rules, the idea-spurring
checklist, and the staged problem-solving model. All summaries are in our own
words.

## The four rules — why each one matters

**1. Defer judgment.** Osborn's core insight is that the judicial mind and the
creative mind interfere with each other. Evaluating an idea the instant it
appears triggers self-censorship: people stop voicing the unpolished thoughts
that are the most fertile. So in the generative phase, *all* critical
judgment — including praise, which implicitly ranks ideas, and including
self-criticism — is suspended. Judgment is not abandoned; it's *postponed* to a
separate, later phase where it's applied deliberately. This single separation is
what makes the rest of the method work.

**2. Quantity breeds quality.** Treat raw volume as the explicit goal. The
reasoning: associative thinking tends to surface conventional ideas first and
original ones later, so the more ideas you force out, the deeper into the
non-obvious you go. A larger pool also gives more material to recombine. Set
numeric targets; they reliably lift output.

**3. Welcome the wild and freewheeling.** Loosen the reins. A far-out idea is
valuable even when unusable, because it stretches the range of what's
considered and often suggests a workable neighbor. Osborn's maxim: it's easier
to tone an idea down than to think one up. Wild ideas also break fixation on the
first, obvious framing.

**4. Combine and improve — "hitchhike."** Ideas are springboards. Encourage
participants to suggest how an existing idea can be turned into a better one, or
how two ideas can be merged into a third. Building on others is collaborative
fuel and tends to produce higher-value ideas than solo generation.

## The idea-spurring checklist (idea manipulation)

When generation stalls, take an existing idea and run it through these
transformations. (This is Osborn's checklist — the ancestor of the later
"SCAMPER" mnemonic.)

- **Put to other uses?** New ways to use it as-is; other uses if modified.
- **Adapt?** What else is like this? What could we copy or emulate?
- **Modify / Magnify?** Change meaning, color, motion, form. Make it bigger,
  stronger, more frequent, exaggerated, add value.
- **Minify?** Make it smaller, lighter, slower, split it, condense, omit.
- **Substitute?** Other ingredients, materials, processes, people, places,
  approaches.
- **Rearrange?** Swap components, change the sequence, change the layout or
  schedule, transpose cause and effect.
- **Reverse?** Turn it backwards, upside down, inside out; swap roles; do the
  opposite.
- **Combine?** Blend units, purposes, appeals, ideas; combine with something
  unrelated.

## Divergence then convergence

Osborn frames creative problem-solving as alternating between opening up and
narrowing down. In practice for a session:

1. **Frame the problem** as a clear, generative question ("In how many ways
   might we…?"). A good question is specific enough to focus and open enough to
   permit range.
2. **Diverge** — apply the four rules; chase quantity and breadth.
3. **Incubate** if possible — stepping away lets new associations form.
4. **Converge** — switch the judicial mind back on: cluster, combine, and select
   against criteria.

The discipline is keeping steps 2 and 4 in separate mental rooms. The whole
method is a structured way of *not* doing both at once.
