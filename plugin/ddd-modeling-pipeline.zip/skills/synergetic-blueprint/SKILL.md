---
name: synergetic-blueprint
description: >
  This skill should be used when the user asks to "run the synergetic blueprint",
  "start the modelling pipeline", "walk me through the DDD pipeline", "go through
  the blueprint steps", "continue the blueprint at step N", "go back to step N", "reload the domain stories",
  "I changed the capability map, re-check the rest", or wants a guided,
  step-by-step modelling effort that critiques or generates a brainstorm,
  capability map, core domain chart, Wardley map, domain story, visual glossary,
  EventStorming board, event model and context map, and feeds every accepted
  artifact into one knowledge graph. Also trigger on "add the next artifact to
  the graph and move on" inside such an effort.
metadata:
  version: "0.2.0"
---

# Synergetic Blueprint — the 11-step pipeline

Drive one modelling effort through eleven ordered steps. At every step the user
decides what happens; the skill never runs ahead. The knowledge graph
(`skills/domain-knowledge-graph`) is the spine: every artifact the user
*accepts* is ingested before moving on, and step 11 closes the loop by checking
every artifact in the graph against every other.

Read `${CLAUDE_PLUGIN_ROOT}/skills/synergetic-blueprint/references/step-table.md`
once at the start — it maps each step to the bundled skill(s) that do the work.

## Ground rules

- **One step at a time.** Announce the step number, its name, and whether it is
  optional or mandatory. Then ask. Never run two steps without a decision in
  between.
- **Three answers, always the same shape.** Offer exactly these choices
  (use the interactive option picker when the client has one):
  1. **Skip** — only shown for optional steps. Mandatory steps do not get it.
  2. **Upload** — the user provides the artifact (photo, export, text). Then run
     the step's *critique* skill on it.
  3. **Generate** — Claude drafts the artifact with the step's *generate* skill,
     shows it, and waits for the user to edit or approve. Treat the user's
     edited version as the artifact of record, never Claude's draft.
- **Accept before ingest.** After critique or generation, ask "accept this
  version, revise it, or replace it?" Only an accepted artifact goes into the
  graph. If the user revises, re-run the critique briefly on the revision.
- **Ingest immediately.** Right after acceptance, load
  `skills/domain-knowledge-graph/SKILL.md` and ingest (seed on the first
  artifact, grow afterwards, revise if the same artifact type already exists).
  Report the ingest's own summary: what connected, what contradicts, what is
  orphaned. Carry contradictions forward as open questions.
- **Keep a running ledger.** Maintain `pipeline-log.md` in the working directory:
  step, decision (skip / upload / generate), artifact file, accepted (y/n),
  ingested (y/n), open questions raised. Show the ledger on request and at
  step 11.
- **Resuming.** If the user says "continue at step N" or a `pipeline-log.md`
  and `graph.ttl` already exist, read both, restate where things stand in
  three lines, and pick up from the first incomplete step.
- **Any step can be revisited.** "Go back to step 5", "reload the domain
  stories", "I changed the capability map" all mean: re-run that step with the
  new artifact, then re-check everything downstream. Follow the procedure in
  *Revisiting a step* below. Never refuse because the step is "done".
- **Never invent inputs.** If a step's skill needs an artifact that was skipped
  earlier (e.g. step 3 needs a capability map), say so and offer: upload it
  now, generate it now, or skip this step too.

## The steps

Run in this order. Bundled skills are under `${CLAUDE_PLUGIN_ROOT}/skills/`.

| # | Step | Kind | Upload → critique with | Generate with | Ingest |
|---|------|------|------------------------|---------------|--------|
| 1 | Brainstorming result | optional | `devils-advocate` | `brainstorm-participant` | yes |
| 2 | Capability Map | optional | `capability-map-critic` | draft from the graph + brainstorm, then `capability-map-critic` | yes |
| 3 | Core Domain Chart | optional | `core-domain-chart-critic` | `core-domain-chart-author` (needs step 2 map + critique) | yes |
| 4 | Wardley Map | optional | `wardley-map-critic` | draft components/evolution from steps 1–3, then `wardley-map-critic` | yes |
| 5 | Domain Story | optional | `domain-story-critic` | `domain-story-seeder` (offer step 2/4 map as focus source) | yes |
| 6 | Visual Glossary | **mandatory** | `visual-glossary-interpreter` | derive terms from step 5 story (or user description) and render with `visual-glossary-updater`'s renderer | yes |
| 7 | Bounded contexts in an EventStorming board | optional | `pivotal-event-boundary-finder` | `event-storming-seeder` / `domain-story-event-seeder` first, then `pivotal-event-boundary-finder` | no (feeds 8) |
| 8 | EventStorming + contexts **or** contexts in Domain Stories | **mandatory** | board: `event-storming-interpreter`; stories: `domain-story-context-finder` | if step 7 ran, reuse it; else `domain-story-context-finder` on step 5 story | yes |
| 9 | Updated Visual Glossary | **mandatory** | `domain-story-glossary-consistency` + `visual-glossary-interpreter` | `visual-glossary-updater` (redraw against contexts from step 8) | yes (revise) |
| 10 | Event Model | optional | `event-model-author` (review mode) | `event-model-author` (story from 5, contexts from 8) | yes |
| 11 | Context Map + full consistency check | **mandatory** | `context-map-board-consistency` | `event-storming-context-mapper` | yes, then final report |

Step-specific notes live in the references file; consult it before each step.

## Revisiting a step

When the user returns to step N after later steps have been completed:

1. **Confirm the target.** Restate which artifact is being replaced and which
   completed downstream steps depend on it (read `pipeline-log.md`; the
   dependency table is in the references file). One short paragraph, then ask
   upload / generate as usual.
2. **Run step N as a revision.** Critique or generate exactly as on the first
   pass. On acceptance, ingest with the knowledge graph's **revise** mode: the
   new artifact gets `dkg:revisionOf` the old one, and the graph reports the
   diff — added, removed, changed. Show that diff; it is the checklist for
   everything that follows.
3. **Re-check downstream, do not regenerate.** For every completed step after N
   that depends on it, in pipeline order, run that step's *consistency check*
   against the revised artifact — never silently rebuild the downstream
   artifact. The checks per step are in the references file under
   *Downstream re-checks*. For each downstream step, report one of:
   - **Still consistent** — nothing to do; note it in the ledger.
   - **Inconsistent** — list the concrete findings (renamed term, dropped
     actor, sentence no longer in any context, slice whose command vanished…)
     and offer three choices: **keep as is** (log the finding as an open
     question), **patch** (Claude proposes the minimal edit, user approves),
     or **redo the step** (full upload/generate cycle, which in turn triggers
     re-checks of *its* downstream steps).
4. **Update the graph** for every patched or redone step, again in revise mode.
   Keep every `dkg:contradicts` edge the user chose to keep.
5. **Update the ledger.** Mark step N and each touched downstream step with a
   revision number (`r2`, `r3`…) and the date, and append the findings the user
   chose to keep to that step's open questions.
6. **Return to the frontier.** After the re-checks, continue from the first
   step that was never completed — or, if all eleven were, re-run the step 11
   closing report so it reflects the revision.

Skipped downstream steps are not re-checked; mention them once so the user can
choose to do them now.

## Step 11 — closing

After the context map is accepted and ingested:

1. Run `context-map-board-consistency` if a board exists (from 7/8).
2. Run `domain-story-glossary-consistency` between the final glossary and every
   story in the graph.
3. Ask the knowledge graph for every `dkg:contradicts` edge and every orphan.
4. Compile **one** final report: a table of artifacts (present / skipped),
   the contradictions still open, the orphans, and every question the
   individual skills asked that the user has not yet answered — grouped by the
   step that raised it. Present the questions as a checklist the user can
   answer in the next session.
5. Deliver: `graph.ttl`, the graph's browsable views, `pipeline-log.md`, and
   the final report. Present all files.

## Tone

Plain language to the user; no file paths or skill names in the conversation
unless asked. Say "I'll critique your capability map" rather than naming the
skill. Keep each step's exchange short: the artifact and the decision, not a
lecture.
