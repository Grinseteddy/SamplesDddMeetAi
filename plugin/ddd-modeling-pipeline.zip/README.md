# ddd-modeling-pipeline

A guided, eleven-step domain-modelling pipeline — the *Synergetic Blueprint* — for Claude. It walks you from a brainstorm to a context map, critiquing or drafting one artifact at a time, and grows a single knowledge graph that ties all of them together. When you change an artifact later, the pipeline re-checks everything downstream and tells you what no longer fits.

## What it does

| # | Step | Kind | Upload → critiqued by | Generate with |
|---|------|------|-----------------------|---------------|
| 1 | Brainstorming result (accept a new one) | optional | Devil's Advocate | Brainstorm participant |
| 2 | Capability Map | optional | Capability-map critic | Strawman from step 1, then critic |
| 3 | Core Domain Chart | optional | Core-domain-chart critic | Core-domain-chart author (needs step 2) |
| 4 | Wardley Map | optional | Wardley-map critic | Strawman from steps 1–3, then critic |
| 5 | Domain Story | optional | Domain-story critic | Domain-story seeder |
| 6 | Visual Glossary | **mandatory** | Visual-glossary interpreter | Terms from step 5, rendered |
| 7 | Bounded contexts on an EventStorming board | optional | Pivotal-event boundary finder | Event seeder, then boundary finder |
| 8 | EventStorming + contexts, **or** contexts from Domain Stories | **mandatory** | EventStorming interpreter / Domain-story context finder | Same |
| 9 | Updated Visual Glossary | **mandatory** | Story–glossary consistency + interpreter | Visual-glossary updater |
| 10 | Event Model | optional | Event-model author (review) | Event-model author |
| 11 | Context Map + full consistency check | **mandatory** | Context-map/board consistency | EventStorming context mapper |

Every artifact you accept is ingested into the knowledge graph immediately. Step 11 closes with one report: artifacts present and skipped, contradictions still open, orphaned nodes, and every question the pipeline asked that you haven't answered yet.

## Installation

Install the `.plugin` file in Claude. The plugin is self-contained: it bundles the orchestrator plus copies of the 20 worker skills it calls, so nothing else needs to be installed.

## Usage

**Start:** in a new chat, say

> run the synergetic blueprint

Claude announces step 1 and asks what to do. At every step you get the same choices:

- **Skip** — optional steps only.
- **Upload** — hand over your artifact (photo, Miro/egon.io export, sticky list, numbered sentences). Claude critiques it.
- **Generate** — Claude drafts it, you edit, Claude critiques your edited version.

Then: *accept*, *revise*, or *replace*. Only accepted artifacts enter the graph.

**Pause and resume:**

> continue the blueprint at step 6

Claude reads the ledger and the graph, restates where things stand, and picks up from the first unfinished step.

**Go back and change something:**

> reload the domain stories
> go back to step 2 — the capability map changed

Claude re-runs that step as a *revision* (the graph keeps the old version and reports the diff), then walks every completed downstream step and runs its consistency check against the change. For each inconsistency you choose:

- **Keep as is** — logged as an open question,
- **Patch** — Claude proposes the minimal edit, you approve,
- **Redo** — full upload/generate cycle for that step (which re-checks *its* downstream steps in turn).

Nothing downstream is ever regenerated silently.

## What to have ready

- A short project name (the graph asks for it at the first artifact).
- Any artifacts you already own. None of steps 1–5 are required.
- For the mandatory steps: something a Visual Glossary can be built from (step 6) and either an EventStorming board or a Domain Story to cut into bounded contexts (step 8). If you have neither, begin with a Domain Story at step 5 — both can be derived from it.

## Outputs

Written to the working directory as you go:

| File | Content |
|------|---------|
| `graph.ttl` | The knowledge graph (Turtle/RDF), plus browsable views |
| `pipeline-log.md` | Ledger: per step — decision, artifact, accepted, ingested, revision, open questions |
| artifact files | Charts, glossaries, event lists, context map, canvases produced along the way |
| closing report | Step 11 summary of contradictions, orphans and unanswered questions |

## Plugin layout

```
ddd-modeling-pipeline/
├── .claude-plugin/plugin.json
├── README.md
└── skills/
    ├── synergetic-blueprint/          # orchestrator — start here
    │   ├── SKILL.md
    │   └── references/step-table.md   # per-step notes, dependency table, downstream re-checks
    ├── domain-knowledge-graph/        # the spine every step feeds
    ├── devils-advocate/  brainstorm-participant/
    ├── capability-map-critic/  core-domain-chart-author/  core-domain-chart-critic/
    ├── wardley-map-critic/
    ├── domain-story-critic/  domain-story-seeder/  domain-story-context-finder/
    ├── visual-glossary-interpreter/  visual-glossary-updater/  domain-story-glossary-consistency/
    ├── pivotal-event-boundary-finder/  event-storming-seeder/  domain-story-event-seeder/
    ├── event-storming-interpreter/  event-storming-context-mapper/  context-map-board-consistency/
    └── event-model-author/
```

## Customising

- **Dependencies between steps** and **which check runs on a revisit** live in `skills/synergetic-blueprint/references/step-table.md`. Edit the two tables there to add or drop a dependency.
- **Which worker skill a step uses** is the table in `skills/synergetic-blueprint/SKILL.md`.
- Any bundled worker skill can be swapped for a newer version by replacing its folder.

## Version

0.2.0 — adds revisiting a step with downstream consistency re-checks.
