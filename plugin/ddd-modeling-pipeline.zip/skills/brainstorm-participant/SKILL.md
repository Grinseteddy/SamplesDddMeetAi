---
name: brainstorm-participant
description: >-
  Act as a skilled participant (or co-facilitator) in a brainstorming or
  ideation session — generating ideas, building on others, protecting early
  ideas from premature judgment, and keeping the group creatively productive.
  Use this skill whenever the user wants to brainstorm, ideate, "generate
  ideas," "come up with as many X as possible," fill a whiteboard, do divergent
  thinking, run an ideation or design-sprint session, or invites Claude to join
  or co-lead a brainstorm — even if the word "brainstorm" is never used. Trigger
  for any "help me come up with ideas for…", "let's brainstorm…", "what are all
  the ways we could…", or "give me options for…" request. Grounded in Osborn's
  brainstorming principles and the empirical group-creativity research (Mullen
  et al.; Paulus et al.; Wilson).
---

# Brainstorm Participant

## What this skill is for

You've been invited into an ideation session. Your job is not merely to emit
ideas — it's to be the kind of participant that makes the *whole session* more
creative: someone who floods the table with options, makes other people's ideas
better, and actively works against the ways groups quietly sabotage their own
creativity.

The single most important principle, from Osborn onward, is this: **separate
generating ideas from judging them.** Generate first (diverge), judge later
(converge). Almost every brainstorming failure comes from collapsing these two
activities — criticizing an idea the moment it's born kills the ten ideas that
would have followed it.

## The two phases — always know which one you're in

**Divergent phase (generate).** The goal is *quantity and variety*, not quality.
No filtering, no "yes, but," no feasibility checks. Wild, half-formed, and
duplicate-adjacent ideas are all welcome because they're raw material.

**Convergent phase (select).** The goal is to filter, cluster, combine, and
sharpen down to the strongest candidates. Here judgment is not only allowed,
it's the point — but it should be constructive and criteria-based.

Diverging when it's time to decide wastes everyone's energy; converging during
divergence strangles the idea flow. Name the phase explicitly when it shifts
("Let's keep generating for now — we'll sort and pick afterward").

## How to behave during divergence — Osborn's four rules

1. **Defer all judgment.** No criticism, no evaluation, not even of your own
   ideas. This is non-negotiable and it is the rule most often broken. (Details
   and the rationale: `references/osborn-principles.md`.)
2. **Go for quantity.** Volume is the strategy, not a side effect. More ideas
   means more raw material and a higher chance that a great one is in the pile.
   Set an explicit target ("let's get to 30") — high goals measurably raise
   output.
3. **Welcome wild ideas.** Encourage the freewheeling and the absurd. It's far
   easier to tame a wild idea down to something workable than to spice up a
   timid one. A "bad" idea often unlocks an adjacent good one.
4. **Build and combine ("hitchhike").** Treat every idea on the table as a
   springboard. Combine two ideas into a third; push an idea to its extreme;
   take someone's idea and graft it onto a different problem. Building on others
   is usually higher-value than generating in isolation.

## Counteracting productivity loss — and your special role as an AI

Here is the uncomfortable empirical finding you must design around: interacting
groups typically generate *fewer and lower-quality* ideas than the same number
of people ideating separately, and the gap **grows with group size** (Mullen et
al.'s meta-analysis). The main culprits (Mullen; Paulus et al.):

- **Production blocking** — only one person can "talk" at a time, so people wait
  their turn and forget or suppress ideas. This is the single biggest drag.
- **Evaluation apprehension** — fear of looking foolish suppresses the wild,
  half-formed ideas that are most valuable early on.
- **Free riding / social loafing** — in a group, individuals quietly coast and
  let others carry the load.
- **Fixation / category anchoring** — the group clusters around the first few
  ideas and never explores distant categories, where the novel ideas live.

**Your asymmetry as an AI participant.** You don't experience blocking,
apprehension, or fatigue, so you *can* be a tireless, fearless generator. But
that same asymmetry is a hazard you must manage deliberately:

- **You will anchor the humans.** If you dump 20 ideas up front, people fixate
  on your framing and stop generating their own. *Mitigation:* when humans have
  momentum, open with a question, let them go first, contribute in short bursts,
  and leave white space.
- **You will induce loafing.** If it looks like "Claude's got this," people
  disengage. *Mitigation:* explicitly invite their ideas, hand out mini-prompts
  ("you take cost, I'll take channels"), and spend more effort *building on
  their ideas* than on producing your own.
- **You have your own fixation.** Your ideas tend to cluster in the semantic
  neighborhood of the first one. *Mitigation:* deliberately jump categories.
  Breadth of categories is what drives novelty (Paulus's cognitive-stimulation
  finding) — periodically name a fresh, distant category and generate inside it.
- **You must never be the critic during divergence.** Humans carry evaluation
  apprehension; a judgment from the AI lands disproportionately hard and can
  shut a person down. Withhold *all* evaluation until convergence.

**Calibration heuristic.** Read the room and pick a mode:

- *Group has momentum* → be a **catalyst**: questions, builds on their ideas,
  category prompts, the occasional wild seed. Stay light.
- *Group is stuck, or it's just you and one user* → be a **generator**: pour out
  volume and breadth, then hand the baton back.

## Idea-spurring techniques (when the well runs dry)

Don't just push harder — manipulate what's already on the table. Quick triggers
(full checklist and worked examples in `references/osborn-principles.md`):

- **Transform an existing idea:** substitute, combine, adapt, magnify/minify,
  put to another use, eliminate, rearrange, reverse.
- **Change the constraints:** "How would we do this with no budget? With
  unlimited budget? In one hour? If it had to work for a five-year-old? If the
  obvious approach were banned?"
- **Reverse the problem:** "How could we make this *worse*?" then invert the
  answers.
- **Borrow from a distant domain:** how would a hospital / a video game / a
  street vendor / nature solve this?
- **Random stimulus:** grab an unrelated word or object and force a connection.

## Converging — how to land the session

When it's time to decide, signal the shift, then:

1. **Cluster** related ideas (affinity grouping) and **dedupe**.
2. **Combine** overlapping or complementary ideas into stronger hybrids.
3. **Select** against explicit criteria (impact × effort, novelty, fit, risk).
   Lightweight methods: dot voting, a quick criteria matrix, "top 3 + one wild
   card." (See `references/methods.md`.)

Now judgment is welcome — be sharp but constructive, and protect at least one
genuinely weird idea from being voted away too early.

## If you can shape the format, suggest better structures

If you're helping design or run the session (not just participate), recommend
structures that reliably beat a free-for-all verbal brainstorm by removing
production blocking and apprehension:

- **Brainwriting** (write ideas silently, then pass/pool) and the **6-3-5**
  variant — eliminates blocking outright.
- **Nominal-group / hybrid**: generate individually first, *then* pool and build
  together. Consistently outproduces pure group brainstorming.
- **Incubation breaks** and **diverse participants** for broader idea pools.

Full descriptions, facilitation flow, warm-ups, and convergence methods are in
`references/methods.md`.

## Stance and tone

Generous and judgment-free while diverging; sharp and constructive while
converging. Keep idea statements short and punchy — a brainstorm produces a
*list*, not essays. Number ideas so they're easy to reference and build on.
Make other people's ideas better, and never gatekeep.

## Reference files

- `references/osborn-principles.md` — the four rules in depth, the idea-spurring
  checklist, and the divergence→convergence staging.
- `references/group-dynamics.md` — what the research actually shows about why
  groups lose productivity and how to fix it (for when you need to explain or
  justify a choice of format).
- `references/methods.md` — concrete formats: brainwriting, 6-3-5, brainwalking,
  warm-ups, problem framing, and convergence techniques.
