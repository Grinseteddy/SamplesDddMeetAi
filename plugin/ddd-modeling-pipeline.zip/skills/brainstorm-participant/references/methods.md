# Methods & Facilitation

Source basis: Wilson, *Brainstorming and Beyond: A User-Centered Design Method*,
with reinforcement from Paulus et al. on why these structures work. Summaries in
our own words. Use when designing or co-running a session, not just
participating.

## Before generating: frame and warm up

- **Frame the problem as a generative question.** "In how many ways might
  we…?" Specific enough to focus energy, open enough to allow range. A vague
  prompt produces vague ideas; an over-narrow one produces none.
- **State the rules out loud.** Defer judgment, go for quantity, welcome wild
  ideas, build on others. Naming them sets the norm and lowers apprehension.
- **Warm up.** A 2–3 minute low-stakes round on a silly unrelated prompt
  ("uses for a paperclip") loosens people up and signals that wild is welcome.
- **Set a target and a timer.** Quantity goals plus a clock create productive
  urgency.

## Generation formats (pick to fit the group)

**Classic verbal brainstorming.** Everyone calls out ideas; someone records all
of them visibly. Energetic and good for building, but exposed to production
blocking and apprehension — best for small groups, short bursts, or warm-ups.

**Brainwriting.** Everyone writes ideas silently and in parallel, then ideas are
passed or pooled and built upon. Removes production blocking and largely
neutralizes apprehension; usually outproduces verbal brainstorming. The default
recommendation when you want raw volume.

**6-3-5.** A structured brainwriting form: ~6 people each write ~3 ideas in ~5
minutes on a sheet, then pass the sheet on; the next person builds on what's
there. Repeats until sheets return. Combines parallel generation with
structured hitchhiking.

**Brainwalking.** Ideas are posted around the room (or board); people move
between stations adding and building. Adds movement and fresh exposure to break
fixation.

**Nominal-group / hybrid.** Generate individually first, *then* convene to pool,
cluster, and build. Captures individual fluency and group cross-stimulation —
strong general-purpose default supported by the research.

## During generation: facilitation moves

- **Record everything visibly and number it.** Visible, numbered ideas are
  easy to reference and build on, and the running count motivates.
- **Protect the rules.** Gently intercept criticism ("park that for the sort —
  keep them coming").
- **Unstick the group** with the idea-spurring checklist, constraint changes, or
  a distant-domain analogy (see `osborn-principles.md`).
- **Steer for breadth.** When ideas cluster in one category, introduce a new,
  distant one.
- **Manage airtime** so no one dominates and quiet members contribute (silent
  rounds help).

## Converging: from many ideas to a decision

1. **Cluster (affinity grouping).** Group similar ideas; themes emerge.
2. **Dedupe and combine.** Merge overlaps; fuse complementary ideas into
   stronger hybrids.
3. **Select against criteria.** Make criteria explicit (impact, effort, novelty,
   fit, risk). Lightweight tools:
   - **Dot voting** — each person gets N dots to distribute; fast prioritization.
   - **Impact × effort matrix** — plot ideas; "high impact / low effort" wins
     first.
   - **Top 3 + wild card** — pick the strongest few plus one deliberately
     unconventional idea so novelty survives the cut.
4. **Capture next steps** — owner and first action for the chosen ideas.

## "And beyond"

The reason to reach past classic verbal brainstorming is precisely the
productivity-loss evidence (see `group-dynamics.md`): the alternative formats
above exist to keep brainstorming's strengths (cross-stimulation, energy,
building) while removing its structural weaknesses (blocking, apprehension,
loafing, fixation). Choose the format that removes the weakness most likely to
bite *this* group.
