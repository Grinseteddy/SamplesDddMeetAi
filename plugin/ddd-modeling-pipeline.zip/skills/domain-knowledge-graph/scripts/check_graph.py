#!/usr/bin/env python3
"""Check a domain knowledge graph.

    python3 check_graph.py graph.ttl
    python3 check_graph.py graph.ttl --sparql query.rq

Errors are things that make the graph untrustworthy: a node with no source
cannot be traced to a wall, a node with no confidence lets a guess pass as a
transcription. Fix those.

Warnings are findings. An orphan, a contradiction, a pending merge — these are
what the graph is FOR. Report them; do not fix them by inventing edges.
"""
from __future__ import annotations

import sys
import argparse
import difflib
from collections import defaultdict

try:
    from rdflib import Graph, RDF, RDFS, Namespace, URIRef, Literal
    from rdflib.namespace import SKOS, OWL
except ImportError:
    sys.exit("rdflib is required:  pip install rdflib --break-system-packages")

DKG = Namespace("https://w3id.org/dkg/ns#")

# Properties that do not, on their own, make a node connected to anything.
BOOKKEEPING = {
    RDF.type, RDFS.label, RDFS.comment, SKOS.prefLabel, SKOS.altLabel,
    DKG.source, DKG.locator, DKG.confidence, DKG.ingestedAt, DKG.votes,
    DKG.sequence, DKG.metric, DKG.cardinality, DKG.cardinalityGiven,
    DKG.verb, DKG.hasState, DKG.sliceKind, DKG.visibility, DKG.literal,
    DKG.messageKind, DKG.carries, DKG.domainRole, DKG.businessModel,
    DKG.status, DKG.decidedOption, DKG.consideredOption, DKG.decidedAt,
    DKG.decidedBy,
    OWL.imports,
}

CONFIDENCES = {DKG.OnArtifact, DKG.Implied, DKG.Inferred}


def label_of(g: Graph, node) -> str:
    for p in (SKOS.prefLabel, RDFS.label):
        v = g.value(node, p)
        if v:
            return str(v)
    return str(node).split("#")[-1]


def normalise(s: str) -> str:
    return "".join(c for c in s.lower() if c.isalnum())


def normalise_words(s: str) -> list[str]:
    cleaned = "".join(c if c.isalnum() or c.isspace() else " " for c in s.lower())
    return cleaned.split()


def load(path: str) -> Graph:
    g = Graph()
    try:
        g.parse(path, format="turtle")
    except Exception as exc:  # noqa: BLE001 - parse errors are the whole point
        sys.exit(f"PARSE FAILED\n  {exc}")
    return load_vocab(g)


def load_vocab(g: Graph) -> Graph:
    """Pull in dkg.ttl if it sits beside the graph or beside this script,
    so subclass closure works. Absent, the checks still run on direct types."""
    import os
    here = os.path.dirname(os.path.abspath(__file__))
    for cand in (os.path.join(here, "..", "assets", "dkg.ttl"),
                 os.path.join(os.getcwd(), "dkg.ttl")):
        if os.path.exists(cand):
            try:
                g.parse(cand, format="turtle")
            except Exception as exc:  # a partial vocab load breaks subclass
                print(f"WARNING: could not load {cand}: {exc}", file=sys.stderr)
            break
    return g


def typed(g: Graph, cls) -> set:
    """Instances of cls or any dkg: subclass of it."""
    out = set(g.subjects(RDF.type, cls))
    for sub in set(g.subjects(RDFS.subClassOf, cls)):
        if sub != cls:
            out |= typed(g, sub)
    return out


def subjects_in_graph(g: Graph) -> set:
    """Everything the file makes a statement about, minus vocabulary terms."""
    out = set()
    for s in set(g.subjects()):
        if isinstance(s, URIRef) and not str(s).startswith(str(DKG)):
            out.add(s)
    return out


def check(g: Graph) -> tuple[list[str], list[str], dict]:
    errors: list[str] = []
    warnings: list[str] = []

    artifact_nodes = typed(g, DKG.Artifact)
    ontology_nodes = set(g.subjects(RDF.type, OWL.Ontology))
    reifications = set(g.subjects(RDF.type, DKG.Assertion))

    nodes = [
        s for s in subjects_in_graph(g)
        if s not in artifact_nodes and s not in ontology_nodes
        and s not in reifications
    ]

    # ---- errors -------------------------------------------------------
    for n in sorted(nodes, key=str):
        name = str(n).split("#")[-1]
        if not list(g.objects(n, RDF.type)):
            errors.append(f"{name}: no rdf:type")
        if not list(g.objects(n, SKOS.prefLabel)):
            errors.append(f"{name}: no skos:prefLabel")
        if not list(g.objects(n, DKG.source)):
            errors.append(f"{name}: no dkg:source — cannot be traced to an artifact")
        conf = list(g.objects(n, DKG.confidence))
        if not conf:
            errors.append(f"{name}: no dkg:confidence")
        elif not set(conf) <= CONFIDENCES:
            errors.append(f"{name}: dkg:confidence is not one of OnArtifact/Implied/Inferred")

    for a in sorted(reifications, key=str):
        name = str(a).split("#")[-1]
        for p, why in ((RDF.subject, "rdf:subject"), (RDF.predicate, "rdf:predicate"),
                       (RDF.object, "rdf:object")):
            if not list(g.objects(a, p)):
                errors.append(f"{name}: assertion with no {why}")
        if not list(g.objects(a, DKG.source)):
            errors.append(f"{name}: assertion with no dkg:source — "
                          "an unsourced claim is worse than no claim")
        if not list(g.objects(a, DKG.confidence)):
            errors.append(f"{name}: assertion with no dkg:confidence")

    for a in sorted(artifact_nodes, key=str):
        if not list(g.objects(a, RDFS.label)):
            errors.append(f"{str(a).split('#')[-1]}: artifact with no rdfs:label")

    # dangling references: pointed at, never described
    described = subjects_in_graph(g)
    for s, p, o in g:
        if isinstance(o, URIRef) and not str(o).startswith(str(DKG)) \
                and "w3.org" not in str(o) and "#" in str(o) \
                and o not in described and p not in (OWL.imports,):
            errors.append(
                f"{str(o).split('#')[-1]}: referenced by "
                f"{str(s).split('#')[-1]} but never described")

    # ---- warnings -----------------------------------------------------
    for s, _, o in g.triples((None, DKG.proposedSameAs, None)):
        warnings.append(
            f"pending merge: {label_of(g, s)!r} ~ {label_of(g, o)!r} "
            "— awaiting a human decision")

    for s, _, o in g.triples((None, DKG.contradicts, None)):
        warnings.append(
            f"contradiction: {label_of(g, s)} vs {label_of(g, o)} "
            "— keep both, report verbatim")

    # orphans: no substantive edge in either direction
    for n in nodes:
        out_edges = [p for p in g.predicates(n, None) if p not in BOOKKEEPING]
        in_edges = [p for p in g.predicates(None, n) if p not in BOOKKEEPING]
        if not out_edges and not in_edges:
            warnings.append(
                f"orphan: {label_of(g, n)!r} connects to nothing — "
                "a finding, not a defect to patch")

    # near-duplicate labels that were not merged or proposed
    labels = defaultdict(list)
    for n in nodes:
        labels[label_of(g, n)].append(n)
    known = set()
    for s, _, o in g.triples((None, DKG.proposedSameAs, None)):
        known.add(frozenset({s, o}))
    for s, _, o in g.triples((None, DKG.contradicts, None)):
        known.add(frozenset({s, o}))
    # Sentences and slices are labelled with whole sentences; they are not
    # duplicate candidates and would otherwise drown the report. Messages are
    # deliberately repeated by label across collaborators (one row per
    # collaborator, same message name) — that repetition is the finding, not
    # a transcription error, so it is skipped here too.
    skip = typed(g, DKG.Sentence) | typed(g, DKG.Slice) | typed(g, DKG.Message)
    fam_cache: dict = {}

    def family(n):
        if n not in fam_cache:
            fam_cache[n] = next(
                (f for f in (DKG.Occurrence, DKG.Activity, DKG.Actor,
                             DKG.Capability, DKG.Goal, DKG.Deliverable,
                             DKG.BoundedContext, DKG.Question, DKG.Rule,
                             DKG.Decision, DKG.Concept)
                 if n in typed(g, f)), None)
        return fam_cache[n]

    names = sorted(labels)
    for i, a in enumerate(names):
        for b in names[i + 1:]:
            for x in labels[a]:
                for y in labels[b]:
                    if x in skip or y in skip:
                        continue
                    if frozenset({x, y}) & set() or frozenset({x, y}) in known:
                        continue
                    fx, fy = family(x), family(y)
                    # An event is named after the thing it happened to. That is
                    # a convention, not a duplicate.
                    if {fx, fy} == {DKG.Occurrence, DKG.Concept} or \
                       {fx, fy} == {DKG.Occurrence, DKG.Activity}:
                        continue
                    ta = [w for w in normalise_words(a)]
                    tb = [w for w in normalise_words(b)]
                    if not ta or not tb:
                        continue
                    ratio = difflib.SequenceMatcher(
                        None, " ".join(ta), " ".join(tb)).ratio()
                    short, long_ = (ta, tb) if len(ta) <= len(tb) else (tb, ta)
                    contained = (fx == fy and len(long_) <= 4
                                 and all(w in long_ for w in short))
                    if ratio > 0.88 or contained:
                        warnings.append(
                            "near-duplicate labels not merged or proposed: "
                            f"{a!r} / {b!r} — decide, and put it in the ledger")

    # confidence distribution is worth seeing
    stats = {
        "nodes": len(nodes),
        "artifacts": len(artifact_nodes),
        "assertions": len(reifications),
        "triples": len(g),
        "by_class": defaultdict(int),
        "by_confidence": defaultdict(int),
        "sources_per_node": defaultdict(int),
    }
    for n in nodes:
        for t in g.objects(n, RDF.type):
            if str(t).startswith(str(DKG)):
                stats["by_class"][str(t).split("#")[-1]] += 1
        for c in g.objects(n, DKG.confidence):
            stats["by_confidence"][str(c).split("#")[-1]] += 1
        stats["sources_per_node"][len(set(g.objects(n, DKG.source)))] += 1

    return errors, warnings, stats


def verdict_of(share: float, cover: float) -> str:
    """share = new labels already held; cover = held labels present in new."""
    if share >= 2 / 3 and cover >= 2 / 3:
        return "REVISION — same picture, redrawn"
    if share >= 2 / 3 and cover < 2 / 3:
        return "PARTITION — a piece of it (or the new one borrows heavily)"
    if share < 1 / 3 and cover >= 2 / 3:
        return "SUPERSET — contains it and much more; revision with additions, or a merge of several"
    if share >= 1 / 3 or cover >= 1 / 3:
        return "ASK — partial overlap"
    return ""


def overlap(g: Graph, key: str, labels_path: str) -> int:
    """Is the arriving artifact a revision of an existing one? Compare the
    transcribed labels (one per line) with the nodes sourced to that artifact.
    key may be an artifact IRI suffix, a label fragment, or 'all' — which
    scores every artifact in the register and reports the best matches, so
    the ingester never has to guess which of five glossaries to test against."""
    arts = typed(g, DKG.Artifact)
    if key.lower() in ("all", "*"):
        with open(labels_path) as fh:
            new = [l.strip() for l in fh if l.strip()]
        edges = typed(g, DKG.Relationship) | typed(g, DKG.Assertion)
        scored = []
        for a in arts:
            held = {normalise(label_of(g, n)) for n in g.subjects(DKG.source, a)
                    if n not in edges}
            if not held:
                continue
            hits = sum(1 for l in new if normalise(l) in held)
            share = hits / len(new) if new else 0      # of the NEW, already held
            cover = hits / len(held)                   # of the EXISTING, present in new
            scored.append((share, cover, hits, a, len(held)))
        scored.sort(key=lambda t: -t[0])
        print(f"{len(new)} transcribed labels against {len(scored)} artifacts "
              "(share = of new labels already held · cover = of held labels present in new):\n")
        for share, cover, hits, a, size in scored[:8]:
            types = ", ".join(str(t).split("#")[-1] for t in g.objects(a, RDF.type)
                              if str(t).startswith(str(DKG)) and str(t) != str(DKG.Artifact))
            print(f"  share {share:4.0%} · cover {cover:4.0%}  ({hits}/{len(new)} of new, "
                  f"{hits}/{size} of held)   {label_of(g, a)}  [{types}]  {verdict_of(share, cover)}")
        print("\nRe-run with the best match named to see added / removed labels. "
              "Several artifacts of the same type at a third or more each usually "
              "means the new one PARTITIONS them (or they partition it) — see "
              "reingest-revision.md §0b.")
        return 0
    art = next((a for a in arts if str(a).split("/")[-1].split("#")[-1] == key), None) \
        or next((a for a in arts if key.lower() in label_of(g, a).lower()), None)
    if art is None:
        print(f"no artifact matches {key!r}")
        return 1
    # relationships and assertions are edges, not labels a transcription lists
    edges = typed(g, DKG.Relationship) | typed(g, DKG.Assertion)
    nodes_of_art = [n for n in g.subjects(DKG.source, art) if n not in edges]
    held = {normalise(label_of(g, n)) for n in nodes_of_art}
    with open(labels_path) as fh:
        new = [l.strip() for l in fh if l.strip()]
    hits = [l for l in new if normalise(l) in held]
    misses = [l for l in new if normalise(l) not in held]
    gone = sorted(l for l in {label_of(g, n) for n in nodes_of_art}
                  if normalise(l) not in {normalise(x) for x in new})
    share = len(hits) / len(new) if new else 0.0
    cover = len(hits) / len(held) if held else 0.0
    verdict = verdict_of(share, cover) or "NEW ARTIFACT"
    print(f"{label_of(g, art)}: {len(hits)} of {len(new)} transcribed labels "
          f"already sourced to it ({share:.0%}); they cover {cover:.0%} of what "
          f"it holds → {verdict}")
    if misses:
        print(f"\nnot in the existing artifact ({len(misses)}) — added, or renamed:")
        for l in misses:
            print(f"  + {l}")
    if gone:
        print(f"\nin the existing artifact, not in the transcription ({len(gone)}) "
              "— removed, or renamed:")
        for l in gone:
            print(f"  - {l}")
    print("\nA label in both lists may be one rename. Decide it in the ledger.")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("graph")
    ap.add_argument("--sparql", help="run a SPARQL query file against the graph")
    ap.add_argument("--overlap", nargs=2, metavar=("ARTIFACT", "LABELS_FILE"),
                    help="revision test: share of transcribed labels (one per "
                         "line) already sourced to ARTIFACT; use 'all' to "
                         "score every artifact in the register")
    ap.add_argument("--quiet", action="store_true", help="errors only")
    args = ap.parse_args()

    g = load(args.graph)

    if args.overlap:
        return overlap(g, args.overlap[0], args.overlap[1])

    if args.sparql:
        with open(args.sparql) as fh:
            q = fh.read()
        for row in g.query(q):
            print(" | ".join(str(x) for x in row))
        return 0

    errors, warnings, stats = check(g)

    print(f"parsed {stats['triples']} triples · {stats['nodes']} nodes · "
          f"{stats['artifacts']} artifacts · {stats['assertions']} assertions")
    if stats["by_class"]:
        print("\nby class")
        for k, v in sorted(stats["by_class"].items(), key=lambda kv: -kv[1]):
            print(f"  {v:4d}  {k}")
    if stats["by_confidence"]:
        print("\nby confidence")
        for k in ("OnArtifact", "Implied", "Inferred"):
            if stats["by_confidence"].get(k):
                print(f"  {stats['by_confidence'][k]:4d}  {k}")
    if stats["sources_per_node"]:
        print("\ncorroboration (artifacts per node)")
        for k in sorted(stats["sources_per_node"]):
            print(f"  {stats['sources_per_node'][k]:4d}  node(s) with {k} source(s)")

    print(f"\nERRORS ({len(errors)}) — fix these")
    for e in errors:
        print(f"  ✗ {e}")
    if not errors:
        print("  none")

    if not args.quiet:
        print(f"\nFINDINGS ({len(warnings)}) — report these, do not patch them")
        for w in warnings:
            print(f"  · {w}")
        if not warnings:
            print("  none")

    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
