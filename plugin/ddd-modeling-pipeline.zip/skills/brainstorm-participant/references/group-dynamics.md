# Group Dynamics: Why Brainstorming Groups Underperform, and How to Fix It

Source basis: Mullen, Johnson & Salas, *Productivity Loss in Brainstorming
Groups: A Meta-Analytic Integration*; and Paulus, Brown et al., *Idea Generation
in Groups: A Basis for Creativity in Organizations*. Summaries are in our own
words. Use this file when you need to explain or justify a choice of session
format.

## The headline finding

When you compare a real, interacting brainstorming group against a "nominal
group" — the same number of people ideating alone, with their non-overlapping
ideas pooled afterward — the nominal group usually wins on **both quantity and
quality** of ideas. And the disadvantage of the interacting group **gets worse
as the group gets larger.** This is robust across the meta-analytic record
(Mullen et al.). The naive intuition that "more heads in a room = more ideas"
is, under typical conditions, wrong.

Important nuance (Paulus et al.): this is not a verdict that groups *can't* be
creative. It's a verdict that *unstructured verbal* group brainstorming leaves
value on the table. With the right structure, groups can match or exceed nominal
performance and gain a real benefit unavailable to isolated individuals —
cross-stimulation.

## The four mechanisms of productivity loss

**1. Production blocking (usually the largest).** In a verbal group, only one
person can speak at a time. While waiting, you rehearse your idea so you don't
forget it (which blocks you from generating new ones), or you forget it, or it
stops feeling relevant. The serial bottleneck is structural, not motivational —
which is why removing the bottleneck (e.g., writing in parallel) recovers so
much.

**2. Evaluation apprehension.** Fear of negative judgment from peers makes
people self-censor exactly the tentative, unusual ideas that early-stage
ideation needs most. Anonymity and judgment-free norms reduce it.

**3. Free riding / social loafing.** Individual effort is hard to identify in a
group, so people unconsciously coast. The larger the group, the more diffuse the
responsibility and the stronger the effect.

**4. Fixation and social matching.** Groups anchor on early ideas and on a
narrow set of categories, and members tend to converge toward the group's
*rate* of output — including matching *downward* to low performers. Both shrink
the explored space.

## The upside groups have: cognitive stimulation

Paulus et al. emphasize the counterweight: hearing others' ideas can trigger
ideas you wouldn't have reached alone, especially when those ideas come from
**different categories**. Attention to a broad range of categories — rather than
drilling one — is a strong driver of both quantity and novelty. The design goal
is to capture this cross-fertilization while suppressing the four losses above.

## Evidence-based mitigations

- **Remove the verbal bottleneck.** Brainwriting / electronic or written
  parallel generation eliminates production blocking. (See `methods.md`.)
- **Generate alone first, then pool and build (hybrid / nominal-group
  technique).** Captures individual fluency *and* group cross-stimulation.
- **Set explicit, high quantity goals.** Specific high targets raise output and
  blunt downward social matching.
- **Push for category breadth.** Periodically introduce a fresh, distant
  category instead of deepening the current one.
- **Train and enforce the rules**, especially deferred judgment — it reduces
  evaluation apprehension.
- **Use breaks / incubation.** Pauses let new associations form and break
  fixation.
- **Make effort visible and use facilitation** to counter free riding.
- **Diversify participants** for a wider base of categories and experiences.

## Practical takeaway for an AI participant

Because you don't suffer blocking, apprehension, or fatigue, you can supply the
*fluency and breadth* that human groups lose — but you must avoid *causing* the
human losses: don't anchor (let people generate before you flood), don't induce
loafing (push effort back to them), and never add evaluation pressure during
divergence. Lean hard into category-jumping; that's where your scale helps most.
